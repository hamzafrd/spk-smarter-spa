<template>
  <h1 class="text-primary-500 inline-block">
    <span class="text-primary-800">Blue</span>House.
  </h1>
</template>

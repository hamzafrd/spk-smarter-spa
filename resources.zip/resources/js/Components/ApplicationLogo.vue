<template>
  <div class="rounded-md dark:bg-primary-50 dark:bg-opacity-50">
    <img src=" /logo.png" alt="logo" class="h-9 w-9" />
  </div>
</template>

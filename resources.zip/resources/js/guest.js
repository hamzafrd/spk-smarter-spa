import.meta.glob(['../fonts/**']);
import './bootstrap';
import '../css/app.css';

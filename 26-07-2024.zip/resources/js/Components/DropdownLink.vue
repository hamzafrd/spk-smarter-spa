<script setup>
import { Link } from '@inertiajs/vue3';

defineProps({
  href: {
    type: String,
    required: true,
  },
});
</script>

<template>
  <Link :href="href"
    class="block w-full px-4 py-2 text-start leading-5 text-gray-700 dark:text-gray-300 hover:bg-primary-100 dark:hover:bg-gray-800 focus:outline-none focus:bg-primary-100 dark:focus:bg-gray-800 transition duration-150 ease-in-out">
  <slot />
  </Link>
</template>

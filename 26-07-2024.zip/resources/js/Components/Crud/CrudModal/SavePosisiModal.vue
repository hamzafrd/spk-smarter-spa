<script setup>
import { useFormStore } from '@/store';
import { storeToRefs } from 'pinia';
const props = defineProps({
  id: {
    type: String,
    default: null,
  },
});
const storePinia = useFormStore();

const { updatePositions, loadListSpa, initLib } = storePinia;
const { massEdit } = storeToRefs(storePinia);
</script>
<template>
  <div id="simpanPosisiModal" aria-hidden="true"
    class="hidden overflow-y-auto overflow-x-hidden fixed top-0 right-0 left-0 z-50 justify-center items-center w-full md:inset-0 h-[calc(100%-1rem)] max-h-full">
    <div class="relative p-4 w-full max-w-md max-h-full">
      <!-- Modal content -->
      <div class="relative p-4 text-center bg-primary-50 rounded-lg shadow dark:bg-gray-800 sm:p-5">
        <button type="button"
          class="text-gray-400 absolute top-2.5 right-2.5 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg p-1.5 ml-auto inline-flex items-center dark:hover:bg-gray-600 dark:hover:text-white"
          data-modal-target="simpanPosisiModal" data-modal-hide="simpanPosisiModal">
          <svg aria-hidden="true" class="w-5 h-5" fill="currentColor" viewbox="0 0 20 20"
            xmlns="http://www.w3.org/2000/svg">
            <path fill-rule="evenodd"
              d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"
              clip-rule="evenodd" />
          </svg>
          <span class="sr-only">Close modal</span>
        </button>
        <svg class="text-gray-400 dark:text-gray-500 w-11 h-11 mb-3.5 mx-auto" aria-hidden="true" fill="currentColor"
          viewbox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
          <path fill-rule="evenodd"
            d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z"
            clip-rule="evenodd" />
        </svg>
        <p class="mb-4 text-gray-500 dark:text-gray-300">
          Yakin tidak save posisi kriteria ?
        </p>
        <div>
          <div class="flex justify-center items-center space-x-4">
            <button type="submit" @click="
              (massEdit = !massEdit),
              loadListSpa(),
              initLib()" data-modal-hide="simpanPosisiModal"
              class="py-2 px-3 font-medium text-gray-500 bg-primary-50 rounded-lg border border-gray-200 hover:bg-primary-100 focus:ring-4 focus:outline-none focus:ring-primary-300 hover:text-gray-900 focus:z-10 dark:bg-gray-700 dark:text-gray-300 dark:border-gray-500 dark:hover:text-white dark:hover:bg-gray-600 dark:focus:ring-gray-600">
              Ya, kembali ke awal
            </button>
            <button type="button" @click="
              (massEdit = !massEdit),
              updatePositions(),
              loadListSpa(),
              initLib()
              " data-modal-hide="simpanPosisiModal"
              class="py-2 px-3 font-medium text-center text-white bg-primary-600 rounded-lg hover:bg-primary-700 focus:ring-4 focus:outline-none focus:ring-red-300 dark:bg-primary-500 dark:hover:bg-primary-600 dark:focus:ring-primary-900">
              Simpan posisi
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

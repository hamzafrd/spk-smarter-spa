<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Smarter extends Model
{
  use HasFactory;

  protected $table = 'smarter';
  protected $guarded = [''];

  public function kriteria()
  {
    return $this->hasMany(Kriteria::class);
  }
  public function alternatif()
  {
    return $this->hasMany(Alternatif::class);
  }
  public function subkriteria()
  {
    return $this->hasManyThrough(SubKriteria::class, Kriteria::class);
  }
}

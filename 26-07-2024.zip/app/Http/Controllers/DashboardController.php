<?php

namespace App\Http\Controllers;

use App\Models\HasilSmarter;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Inertia\Inertia;

class DashboardController extends Controller
{
  /**
   * Display a listing of the resource.
   */
  public function index()
  {
    $user = User::find(Auth::id());
    $kriteria = $user->kriteria()->with('subkriteria')->with('smarter')->get();
    $alternatif = $user->alternatif()->get();
    $hasil = HasilSmarter::where('user_id', Auth::id())->get();

    return Inertia::render('Dashboard/IndexDashboard', ['kriteriaList' => $kriteria, 'alternatifList' => $alternatif, 'hasilList' => $hasil]);
  }

  /**
   * Show the form for creating a new resource.
   */
  public function create()
  {
    //
  }

  /**
   * Store a newly created resource in storage.
   */
  public function store(Request $request)
  {
    //
  }

  /**
   * Display the specified resource.
   */
  public function show(string $id)
  {
    //
  }

  /**
   * Show the form for editing the specified resource.
   */
  public function edit(string $id)
  {
    //
  }

  /**
   * Update the specified resource in storage.
   */
  public function update(Request $request, string $id)
  {
    //
  }

  /**
   * Remove the specified resource from storage.
   */
  public function destroy(string $id)
  {
    //
  }
}
